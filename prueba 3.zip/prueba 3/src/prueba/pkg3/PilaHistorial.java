/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
public class PilaHistorial {

    private NodoPedido cima;

    public PilaHistorial() {

        cima = null;
    }

    public boolean estaVacia() {

        return cima == null;
    }

    public void push(Pedido pedido) {

        NodoPedido nuevo = new NodoPedido(pedido);
        nuevo.siguiente = cima;
        cima = nuevo;
    }

    public Pedido pop() {

        if (estaVacia())
            return null;

        Pedido p = cima.pedido;
        cima = cima.siguiente;
        return p;
    }

    public Pedido peek() {

        if (estaVacia())
            return null;
        return cima.pedido;

    }

    public void mostrar() {

        NodoPedido aux = cima;

        while (aux != null) {
            System.out.println(aux.pedido);
            System.out.println("----------------");
            aux = aux.siguiente;
        }
    }

    
    
    
    
}