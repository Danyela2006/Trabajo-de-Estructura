/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
public class ListaPedidos {

    private NodoPedido inicio;

    public ListaPedidos() {
        inicio = null;
    }

    public boolean estaVacia() {
        return inicio == null;
    }

    public void agregar(Pedido pedido) {

        NodoPedido nuevo = new NodoPedido(pedido);

        if (inicio == null) {
            inicio = nuevo;
            return;
        }

        NodoPedido aux = inicio;

        while (aux.siguiente != null) {
            aux = aux.siguiente;
        }

        aux.siguiente = nuevo;

    }

    public Pedido buscar(int codigo) {

        NodoPedido aux = inicio;

        while (aux != null) {

            if (aux.pedido.getCodigo() == codigo) {
                return aux.pedido;
            }

            aux = aux.siguiente;
        }

        return null;

    }

    public boolean eliminar(int codigo) {

        if (inicio == null)
            return false;

        if (inicio.pedido.getCodigo() == codigo) {
            inicio = inicio.siguiente;
            return true;
        }

        NodoPedido ant = inicio;
        NodoPedido act = inicio.siguiente;

        while (act != null) {

            if (act.pedido.getCodigo() == codigo) {

                ant.siguiente = act.siguiente;
                return true;

            }

            ant = act;
            act = act.siguiente;

        }

        return false;

    }

    public void mostrar() {

        NodoPedido aux = inicio;

        while (aux != null) {

            System.out.println(aux.pedido);
            System.out.println("---------------------");

            aux = aux.siguiente;

        }

    }

    public NodoPedido getInicio() {
        return inicio;
    }

    
    
    
}