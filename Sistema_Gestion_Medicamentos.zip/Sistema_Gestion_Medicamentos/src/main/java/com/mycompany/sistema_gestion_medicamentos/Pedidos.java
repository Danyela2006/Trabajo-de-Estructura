/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.sistema_gestion_medicamentos;

/**
 *
 * @author Usuario
 */
public class Pedidos {
    private int CodUnico;
    private InstitucionMedica institucion;
    private String fechaSolicitud; // DD/MM/AAAA
    private String TipoMed;
    private int CantMed;
    private int NivelPriori;// 1. Alto, 2. Medio, 3. Bajo y 4. No se sabe
    private String fechaMaxEntrega; // DD/MM/AAAA
    private String estado; // Pendiente, En despacho, Completado
    private String responsable;

    public Pedidos(int CodUnico, InstitucionMedica institucion, String fechaSolicitud, String TipoMed, int CantMed, int NivelPriori, String fechaMaxEntrega, String estado, String responsable) {
        this.CodUnico = CodUnico;
        this.institucion = institucion;
        this.fechaSolicitud = fechaSolicitud;
        this.TipoMed = TipoMed;
        this.CantMed = CantMed;
        this.NivelPriori = NivelPriori;
        this.fechaMaxEntrega = fechaMaxEntrega;
        this.estado = estado;
        this.responsable = responsable;
    }

    public int getCodUnico() {
        return CodUnico;
    }

    public void setCodUnico(int CodUnico) {
        this.CodUnico = CodUnico;
    }

    public InstitucionMedica getInstitucion() {
        return institucion;
    }

    public void setInstitucion(InstitucionMedica institucion) {
        this.institucion = institucion;
    }

    public String getFechaSolicitud() {
        return fechaSolicitud;
    }

    public void setFechaSolicitud(String fechaSolicitud) {
        this.fechaSolicitud = fechaSolicitud;
    }

    public String getTipoMed() {
        return TipoMed;
    }

    public void setTipoMed(String TipoMed) {
        this.TipoMed = TipoMed;
    }

    public int getCantMed() {
        return CantMed;
    }

    public void setCantMed(int CantMed) {
        this.CantMed = CantMed;
    }

    public int getNivelPriori() {
        return NivelPriori;
    }

    public void setNivelPriori(int NivelPriori) {
        this.NivelPriori = NivelPriori;
    }

    public String getFechaMaxEntrega() {
        return fechaMaxEntrega;
    }

    public void setFechaMaxEntrega(String fechaMaxEntrega) {
        this.fechaMaxEntrega = fechaMaxEntrega;
    }

    public String getEstado() {
        return estado;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public String getResponsable() {
        return responsable;
    }

    public void setResponsable(String responsable) {
        this.responsable = responsable;
    }

    @Override
    public String toString() {
        return "Pedidos{" + "CodUnico=" + CodUnico + ", institucion=" + institucion + ", fechaSolicitud=" + fechaSolicitud + ", TipoMed=" + TipoMed + ", CantMed=" + CantMed + ", NivelPriori=" + NivelPriori + ", fechaMaxEntrega=" + fechaMaxEntrega + ", estado=" + estado + ", responsable=" + responsable + '}';
    }
    
    
    
}
