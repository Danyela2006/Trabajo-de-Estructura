/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.sistema_gestion_medicamentos;

/**
 *
 * @author Usuario
 */
public class Sistema_Gestion_Medicamentos {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
