/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
public class Pedido {

    private int codigo;
    private String institucion;
    private String tipoInstitucion;
    private String fechaSolicitud;
    private String medicamento;
    private int cantidad;
    private int prioridad;
    private String fechaEntrega;
    private String estado;
    private String responsable;

    public Pedido(int codigo, String institucion, String tipoInstitucion,
            String fechaSolicitud, String medicamento,
            int cantidad, int prioridad,
            String fechaEntrega, String estado,
            String responsable) {

        this.codigo = codigo;
        this.institucion = institucion;
        this.tipoInstitucion = tipoInstitucion;
        this.fechaSolicitud = fechaSolicitud;
        this.medicamento = medicamento;
        this.cantidad = cantidad;
        this.prioridad = prioridad;
        this.fechaEntrega = fechaEntrega;
        this.estado = estado;
        this.responsable = responsable;
    }

    public int getCodigo() {
        return codigo;
    }

    public String getInstitucion() {
        return institucion;
    }

    public String getTipoInstitucion() {
        return tipoInstitucion;
    }

    public String getFechaSolicitud() {
        return fechaSolicitud;
    }

    public String getMedicamento() {
        return medicamento;
    }

    public int getCantidad() {
        return cantidad;
    }

    public int getPrioridad() {
        return prioridad;
    }

    public String getFechaEntrega() {
        return fechaEntrega;
    }

    public String getEstado() {
        return estado;
    }

    public String getResponsable() {
        return responsable;
    }

    public void setEstado(String estado) {
        this.estado = estado;
    }

    public void setResponsable(String responsable) {
        this.responsable = responsable;
    }

    public void setPrioridad(int prioridad) {
        this.prioridad = prioridad;
    }

    @Override
    public String toString() {
        return "\nCodigo: " + codigo
                + "\nInstitucion: " + institucion
                + "\nTipo: " + tipoInstitucion
                + "\nFecha Solicitud: " + fechaSolicitud
                + "\nMedicamento: " + medicamento
                + "\nCantidad: " + cantidad
                + "\nPrioridad: " + prioridad
                + "\nFecha Entrega: " + fechaEntrega
                + "\nEstado: " + estado
                + "\nResponsable: " + responsable;
    }

}
