/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
import java.util.Scanner;

public class sistema_de_pedidos {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        SistemaLogistico sistema = new SistemaLogistico();

        int opcion;

        do {

            System.out.println("\n====== SISTEMA LOGÍSTICO ======");

            System.out.println("1. Registrar pedido");
            System.out.println("2. Buscar pedido");
            System.out.println("3. Eliminar pedido");
            System.out.println("4. Mostrar pedidos");
            System.out.println("5. Despachar pedido");
            System.out.println("6. Mostrar BST");
            System.out.println("7. Mostrar AVL");
            System.out.println("8. Mostrar historial");
            System.out.println("9. Ordenar por prioridad");
            System.out.println("10. Ordenar por código");
            System.out.println("0. Salir");

            opcion = sc.nextInt();

            switch (opcion) {

                case 1:

                    System.out.print("Código: ");
                    int codigo = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Nombre de institucion: ");
                    String institucion = sc.nextLine();

                    System.out.print("Tipo de institucion: ");
                    String tipo = sc.nextLine();

                    System.out.print("Fecha solicitud: ");
                    String fechaS = sc.nextLine();

                    System.out.print("Medicamento: ");
                    String med = sc.nextLine();

                    System.out.print("Cantidad: ");
                    int cantidad = sc.nextInt();

                    System.out.print("Prioridad: \n");
                    System.out.println("1. Alto \n"
                                     + "2. Medio \n"
                                     + "3. Bajo");
                    int prioridad = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Fecha entrega: ");
                    String fechaE = sc.nextLine();

                    System.out.print("Estado: ");
                    String estado = sc.nextLine();

                    System.out.print("Responsable: ");
                    String responsable = sc.nextLine();

                    Pedido p = new Pedido(
                            codigo,
                            institucion,
                            tipo,
                            fechaS,
                            med,
                            cantidad,
                            prioridad,
                            fechaE,
                            estado,
                            responsable);

                    sistema.registrar(p);

                    break;

                case 2:

                    System.out.print("Código: ");

                    Pedido encontrado = sistema.buscar(sc.nextInt());

                    if (encontrado == null)
                        System.out.println("No existe.");
                    else
                        System.out.println(encontrado);

                    break;

                case 3:

                    System.out.print("Código: ");

                    sistema.eliminar(sc.nextInt());

                    break;

                case 4:

                    sistema.mostrarLista();

                    break;

                case 5:

                    sistema.despacharPedido();

                    break;

                case 6:

                    sistema.mostrarBST();

                    break;

                case 7:

                    sistema.mostrarAVL();

                    break;

                case 8:

                    sistema.mostrarHistorial();

                    break;

                case 9:

                    sistema.ordenarPrioridad();

                    break;

                case 10:

                    sistema.ordenarCodigo();

                    break;

            }

        } while (opcion != 0);

    }

}