/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
public class Ordenamientos {

    public static void insertionSort(Pedido[] pedidos) {

        for (int i = 1; i < pedidos.length; i++) {
            Pedido actual = pedidos[i];
            int j = i - 1;
            while (j >= 0 &&
                   pedidos[j].getPrioridad() >
                   actual.getPrioridad()) {

                pedidos[j + 1] = pedidos[j];

                j--;
            }
            pedidos[j + 1] = actual;
        }
    }

    public static void mergeSort(Pedido[] pedidos) {
        mergeSort(pedidos, 0, pedidos.length - 1);
    }

    private static void mergeSort(Pedido[] pedidos, int izquierda, int derecha) {
        if (izquierda < derecha) {
            int medio = (izquierda + derecha) / 2;
            mergeSort(pedidos, izquierda, medio);
            mergeSort(pedidos, medio + 1, derecha);
            merge(pedidos, izquierda, medio, derecha);
        }
    }

    private static void merge(Pedido[] pedidos, int izquierda, int medio, int derecha) {

        int n1 = medio - izquierda + 1;
        int n2 = derecha - medio;
        Pedido[] L = new Pedido[n1];
        Pedido[] R = new Pedido[n2];
        for (int i = 0; i < n1; i++)
            L[i] = pedidos[izquierda + i];
        for (int j = 0; j < n2; j++)
            R[j] = pedidos[medio + 1 + j];
        
        int i = 0;
        int j = 0;
        int k = izquierda;
        
        while (i < n1 && j < n2) {

            if (L[i].getCodigo() <= R[j].getCodigo()) {
                pedidos[k] = L[i];
                i++;
            } else {
                pedidos[k] = R[j];
                j++;
            }
            k++;
        }
        while (i < n1) {

            pedidos[k] = L[i];
            i++;
            k++;

        }
        while (j < n2) {

            pedidos[k] = R[j];
            j++;
            k++;
        }
    }
}
