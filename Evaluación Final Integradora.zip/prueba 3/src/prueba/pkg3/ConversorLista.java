/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
public class ConversorLista {

    public static Pedido[] convertir(ListaPedidos lista) {

        int cantidad = contar(lista);
        Pedido[] pedidos = new Pedido[cantidad];
        NodoPedido aux = lista.getInicio();
        int i = 0;
        while (aux != null) {
            pedidos[i] = aux.pedido;
            aux = aux.siguiente;
            i++;
        }

        return pedidos;
    }

    private static int contar(ListaPedidos lista) {
        int contador = 0;
        NodoPedido aux = lista.getInicio();
        while (aux != null) {

            contador++;
            aux = aux.siguiente;
        }
        return contador;
    }

    
    
    
}
