/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
public class NodoPedido {

    public Pedido pedido;

    public NodoPedido siguiente;

    // Árboles
    public NodoPedido izquierda;
    public NodoPedido derecha;

    public int altura;

    public NodoPedido(Pedido pedido) {
        this.pedido = pedido;
        siguiente = null;
        izquierda = null;
        derecha = null;
        altura = 1;
    }

    
    
    
    
}
