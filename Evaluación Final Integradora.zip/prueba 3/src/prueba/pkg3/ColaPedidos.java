/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;
/**
 *
 * @author KEKO JONES
 */
public class ColaPedidos {

    private NodoPedido frente;
    private NodoPedido fin;

    public ColaPedidos() {
        frente = null;
        fin = null;
    }

    public boolean estaVacia() {
        return frente == null;
    }

    public void encolar(Pedido pedido) {

        NodoPedido nuevo = new NodoPedido(pedido);

        if (estaVacia()) {

            frente = nuevo;
            fin = nuevo;

        } else {

            fin.siguiente = nuevo;
            fin = nuevo;

        }

    }

    public Pedido desencolar() {

        if (estaVacia())
            return null;

        Pedido p = frente.pedido;

        frente = frente.siguiente;

        if (frente == null)
            fin = null;

        return p;

    }

    public Pedido frente() {

        if (estaVacia())
            return null;

        return frente.pedido;

    }

    
    
    
}
