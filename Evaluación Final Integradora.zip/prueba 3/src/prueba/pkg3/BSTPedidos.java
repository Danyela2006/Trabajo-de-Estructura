/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
public class BSTPedidos {

    private NodoPedido raiz;

    public BSTPedidos() {
        raiz = null;
    }

    public NodoPedido getRaiz() {
        return raiz;
    }

    public void insertar(Pedido pedido) {
        raiz = insertarRec(raiz, pedido);
    }

    private NodoPedido insertarRec(NodoPedido nodo, Pedido pedido) {

        if (nodo == null)
            return new NodoPedido(pedido);

        if (pedido.getCodigo() < nodo.pedido.getCodigo())
            nodo.izquierda = insertarRec(nodo.izquierda, pedido);

        else if (pedido.getCodigo() > nodo.pedido.getCodigo())
            nodo.derecha = insertarRec(nodo.derecha, pedido);

        return nodo;
    }

    public Pedido buscar(int codigo) {

        NodoPedido aux = buscarNodo(raiz, codigo);

        if (aux == null)
            return null;

        return aux.pedido;
    }

    private NodoPedido buscarNodo(NodoPedido nodo, int codigo) {

        if (nodo == null)
            return null;

        if (codigo == nodo.pedido.getCodigo())
            return nodo;

        if (codigo < nodo.pedido.getCodigo())
            return buscarNodo(nodo.izquierda, codigo);

        return buscarNodo(nodo.derecha, codigo);

    }

    public void eliminar(int codigo) {
        raiz = eliminarRec(raiz, codigo);
    }

    private NodoPedido eliminarRec(NodoPedido nodo, int codigo) {

        if (nodo == null)
            return null;

        if (codigo < nodo.pedido.getCodigo()) {

            nodo.izquierda = eliminarRec(nodo.izquierda, codigo);

        } else if (codigo > nodo.pedido.getCodigo()) {

            nodo.derecha = eliminarRec(nodo.derecha, codigo);

        } else {

            // sin hijos

            if (nodo.izquierda == null && nodo.derecha == null)
                return null;

            // un hijo

            if (nodo.izquierda == null)
                return nodo.derecha;

            if (nodo.derecha == null)
                return nodo.izquierda;

            NodoPedido sucesor = minimo(nodo.derecha);

            nodo.pedido = sucesor.pedido;

            nodo.derecha = eliminarRec(
                    nodo.derecha,
                    sucesor.pedido.getCodigo());

        }

        return nodo;

    }

    private NodoPedido minimo(NodoPedido nodo) {

        while (nodo.izquierda != null)
            nodo = nodo.izquierda;

        return nodo;

    }
    
    public void inOrden() {
        inOrdenRec(raiz);
    }

    private void inOrdenRec(NodoPedido nodo) {

        if (nodo != null) {

            inOrdenRec(nodo.izquierda);

            System.out.println(nodo.pedido);
            System.out.println("---------------------");

            inOrdenRec(nodo.derecha);

        }

    }

    public void preOrden() {
        preOrdenRec(raiz);
    }

    private void preOrdenRec(NodoPedido nodo) {

        if (nodo != null) {

            System.out.println(nodo.pedido);

            preOrdenRec(nodo.izquierda);

            preOrdenRec(nodo.derecha);

        }

    }

    public void postOrden() {
        postOrdenRec(raiz);
    }

    private void postOrdenRec(NodoPedido nodo) {

        if (nodo != null) {

            postOrdenRec(nodo.izquierda);

            postOrdenRec(nodo.derecha);

            System.out.println(nodo.pedido);

        }
    }

    
    
    
}
