/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
public class Busqueda {

    public static Pedido buscarCodigo(ListaPedidos lista, int codigo) {

        NodoPedido aux = lista.getInicio();
        while (aux != null) {
            if (aux.pedido.getCodigo() == codigo)
                return aux.pedido;
            aux = aux.siguiente;
        }

        return null;
    }

    public static void buscarInstitucion(ListaPedidos lista, String nombre) {

        NodoPedido aux = lista.getInicio();
        boolean encontrado = false;

        while (aux != null) {

            if (aux.pedido.getInstitucion()
                    .equalsIgnoreCase(nombre)) {
                System.out.println(aux.pedido);
                encontrado = true;
            }
            aux = aux.siguiente;
        }
        if (!encontrado)
            System.out.println("No se encontraron pedidos.");
    }

    public static Pedido busquedaBinaria(Pedido[] pedidos, int codigo) {

        int izquierda = 0;
        int derecha = pedidos.length - 1;
        while (izquierda <= derecha) {

            int medio = (izquierda + derecha) / 2;
            if (pedidos[medio].getCodigo() == codigo)
                return pedidos[medio];
            if (codigo < pedidos[medio].getCodigo())
                derecha = medio - 1;
            else
                izquierda = medio + 1;
        }
        return null;
    }

}