/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
public class AVLPedidos {

    private NodoPedido raiz;

    public AVLPedidos() {
        raiz = null;
    }

    public NodoPedido getRaiz() {
        return raiz;
    }

    private int altura(NodoPedido n) {
        if (n == null)
            return 0;
        return n.altura;
    }

    private int mayor(int a, int b) {
        return (a > b) ? a : b;
    }

    private int factorBalance(NodoPedido n) {
        if (n == null)
            return 0;

        return altura(n.izquierda) - altura(n.derecha);
    }

    private NodoPedido rotacionDerecha(NodoPedido y) {

        NodoPedido x = y.izquierda;
        NodoPedido t2 = x.derecha;
        x.derecha = y;
        y.izquierda = t2;
        y.altura = mayor(altura(y.izquierda), altura(y.derecha)) + 1;
        x.altura = mayor(altura(x.izquierda), altura(x.derecha)) + 1;
        return x;
    }

    private NodoPedido rotacionIzquierda(NodoPedido x) {

        NodoPedido y = x.derecha;
        NodoPedido t2 = y.izquierda;
        y.izquierda = x;
        x.derecha = t2;
        x.altura = mayor(altura(x.izquierda), altura(x.derecha)) + 1;
        y.altura = mayor(altura(y.izquierda), altura(y.derecha)) + 1;
        return y;
    }

    public void insertar(Pedido pedido) {
        raiz = insertarRec(raiz, pedido);
    }

    private NodoPedido insertarRec(NodoPedido nodo, Pedido pedido) {

        if (nodo == null)
            return new NodoPedido(pedido);
        
        if (pedido.getPrioridad() < nodo.pedido.getPrioridad()) {
            nodo.izquierda = insertarRec(nodo.izquierda, pedido);
        } else {
            nodo.derecha = insertarRec(nodo.derecha, pedido);
        }
        
        nodo.altura = 1 + mayor(
                altura(nodo.izquierda),
                altura(nodo.derecha));
        int balance = factorBalance(nodo);
        
        if (balance > 1 &&
                pedido.getPrioridad() < nodo.izquierda.pedido.getPrioridad())
            return rotacionDerecha(nodo);
        if (balance < -1 &&
                pedido.getPrioridad() > nodo.derecha.pedido.getPrioridad())
            return rotacionIzquierda(nodo);
        if (balance > 1 &&
                pedido.getPrioridad() > nodo.izquierda.pedido.getPrioridad()) {
            nodo.izquierda = rotacionIzquierda(nodo.izquierda);
            return rotacionDerecha(nodo);
        }
        if (balance < -1 &&
                pedido.getPrioridad() < nodo.derecha.pedido.getPrioridad()) {
            nodo.derecha = rotacionDerecha(nodo.derecha);
            
            return rotacionIzquierda(nodo);
        }
        return nodo;
    }
    
    public Pedido buscar(int prioridad) {

        NodoPedido aux = buscarRec(raiz, prioridad);
        if (aux == null)
            return null;
        return aux.pedido;

    }

    private NodoPedido buscarRec(NodoPedido nodo, int prioridad) {

        if (nodo == null)
            return null;
        if (prioridad == nodo.pedido.getPrioridad())
            return nodo;
        if (prioridad < nodo.pedido.getPrioridad())
            return buscarRec(nodo.izquierda, prioridad);

        return buscarRec(nodo.derecha, prioridad);

    }

    public void inOrden() {
        inOrden(raiz);
    }

    private void inOrden(NodoPedido nodo) {

        if (nodo != null) {
            inOrden(nodo.izquierda);
            System.out.println(nodo.pedido);
            inOrden(nodo.derecha);
        }
    }

    public void preOrden() {
        preOrden(raiz);
    }

    private void preOrden(NodoPedido nodo) {

        if (nodo != null) {
            System.out.println(nodo.pedido);
            preOrden(nodo.izquierda);
            preOrden(nodo.derecha);
        }
    }

    public void postOrden() {
        postOrden(raiz);
    }

    private void postOrden(NodoPedido nodo) {

        if (nodo != null) {
            postOrden(nodo.izquierda);
            postOrden(nodo.derecha);
            System.out.println(nodo.pedido);
        }
    }

}
