/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package prueba.pkg3;

/**
 *
 * @author KEKO JONES
 */
public class SistemaLogistico {

    private ListaPedidos lista;
    private ColaPedidos cola;
    private PilaHistorial historial;
    private BSTPedidos bst;
    private AVLPedidos avl;

    public SistemaLogistico() {

        lista = new ListaPedidos();
        cola = new ColaPedidos();
        historial = new PilaHistorial();
        bst = new BSTPedidos();
        avl = new AVLPedidos();
    }

    public void registrar(Pedido pedido) {

        lista.agregar(pedido);
        cola.encolar(pedido);
        bst.insertar(pedido);
        avl.insertar(pedido);
    }

    public Pedido buscar(int codigo) {

        return bst.buscar(codigo);
    }

    public void eliminar(int codigo) {

        lista.eliminar(codigo);
        bst.eliminar(codigo);
    }

    public void cambiarEstado(int codigo, String estadoNuevo) {
        Pedido pedido = bst.buscar(codigo);

        if (pedido != null) {
            historial.push(new Pedido(
                    pedido.getCodigo(),
                    pedido.getInstitucion(),
                    pedido.getTipoInstitucion(),
                    pedido.getFechaSolicitud(),
                    pedido.getMedicamento(),
                    pedido.getCantidad(),
                    pedido.getPrioridad(),
                    pedido.getFechaEntrega(),
                    pedido.getEstado(),
                    pedido.getResponsable()));
            pedido.setEstado(estadoNuevo);
        }

    }

    public void cambiarResponsable(int codigo,String responsable) {
        Pedido pedido = bst.buscar(codigo);

        if (pedido != null) {
            historial.push(new Pedido(
                    pedido.getCodigo(),
                    pedido.getInstitucion(),
                    pedido.getTipoInstitucion(),
                    pedido.getFechaSolicitud(),
                    pedido.getMedicamento(),
                    pedido.getCantidad(),
                    pedido.getPrioridad(),
                    pedido.getFechaEntrega(),
                    pedido.getEstado(),
                    pedido.getResponsable()));

            pedido.setResponsable(responsable);

        }

    }

    public void despacharPedido() {
        Pedido p = cola.desencolar();

        if (p == null) {
            System.out.println("No hay pedidos.");
            return;
        }
        p.setEstado("Despachado");
        System.out.println("Pedido despachado");
        System.out.println(p);
    }

    public void mostrarLista() {

        lista.mostrar();
    }

    public void mostrarBST() {

        bst.inOrden();
    }

    public void mostrarAVL() {

        avl.inOrden();
    }

    public void mostrarHistorial() {

        historial.mostrar();
    }
    
    public void ordenarPrioridad() {
        Pedido[] pedidos = ConversorLista.convertir(lista);
        Ordenamientos.insertionSort(pedidos);

        for (Pedido p : pedidos)
            System.out.println(p);
    }

    public void ordenarCodigo() {
        Pedido[] pedidos = ConversorLista.convertir(lista);
        Ordenamientos.mergeSort(pedidos);

        for (Pedido p : pedidos)
            System.out.println(p);
    }  
}
